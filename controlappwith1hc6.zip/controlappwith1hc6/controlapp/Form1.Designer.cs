﻿namespace controlapp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.videoSTREAM = new MetroFramework.Controls.MetroPanel();
            this.lblLINK = new MetroFramework.Controls.MetroLabel();
            this.btnSSTOP = new MetroFramework.Controls.MetroButton();
            this.btnSSTART = new MetroFramework.Controls.MetroButton();
            this.txtIPLINK = new MetroFramework.Controls.MetroTextBox();
            this.videoBOX = new System.Windows.Forms.PictureBox();
            this.botCONTROL = new MetroFramework.Controls.MetroPanel();
            this.botCAR = new MetroFramework.Controls.MetroPanel();
            this.btnLEFT = new MetroFramework.Controls.MetroTile();
            this.btnFORWARD = new MetroFramework.Controls.MetroTile();
            this.btnBACKWARD = new MetroFramework.Controls.MetroTile();
            this.btnRIGHT = new MetroFramework.Controls.MetroTile();
            this.botARM = new MetroFramework.Controls.MetroPanel();
            this.btnACTIVATEARM = new MetroFramework.Controls.MetroTile();
            this.cmbCOMP = new MetroFramework.Controls.MetroComboBox();
            this.btnDISCONNECT = new MetroFramework.Controls.MetroButton();
            this.btnCONNECT = new MetroFramework.Controls.MetroButton();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.videoSTREAM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.videoBOX)).BeginInit();
            this.botCONTROL.SuspendLayout();
            this.botCAR.SuspendLayout();
            this.botARM.SuspendLayout();
            this.SuspendLayout();
            // 
            // videoSTREAM
            // 
            this.videoSTREAM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.videoSTREAM.Controls.Add(this.lblLINK);
            this.videoSTREAM.Controls.Add(this.btnSSTOP);
            this.videoSTREAM.Controls.Add(this.btnSSTART);
            this.videoSTREAM.Controls.Add(this.txtIPLINK);
            this.videoSTREAM.Controls.Add(this.videoBOX);
            this.videoSTREAM.HorizontalScrollbarBarColor = true;
            this.videoSTREAM.HorizontalScrollbarHighlightOnWheel = false;
            this.videoSTREAM.HorizontalScrollbarSize = 10;
            this.videoSTREAM.Location = new System.Drawing.Point(7, 63);
            this.videoSTREAM.Name = "videoSTREAM";
            this.videoSTREAM.Size = new System.Drawing.Size(442, 451);
            this.videoSTREAM.TabIndex = 0;
            this.videoSTREAM.VerticalScrollbarBarColor = true;
            this.videoSTREAM.VerticalScrollbarHighlightOnWheel = false;
            this.videoSTREAM.VerticalScrollbarSize = 10;
            // 
            // lblLINK
            // 
            this.lblLINK.AutoSize = true;
            this.lblLINK.Location = new System.Drawing.Point(17, 369);
            this.lblLINK.Name = "lblLINK";
            this.lblLINK.Size = new System.Drawing.Size(56, 19);
            this.lblLINK.TabIndex = 6;
            this.lblLINK.Text = "IP Link ::";
            // 
            // btnSSTOP
            // 
            this.btnSSTOP.Location = new System.Drawing.Point(309, 411);
            this.btnSSTOP.Name = "btnSSTOP";
            this.btnSSTOP.Size = new System.Drawing.Size(93, 29);
            this.btnSSTOP.TabIndex = 5;
            this.btnSSTOP.Text = "Stream Stop";
            this.btnSSTOP.UseSelectable = true;
            this.btnSSTOP.Click += new System.EventHandler(this.btnSSTOP_Click);
            // 
            // btnSSTART
            // 
            this.btnSSTART.Location = new System.Drawing.Point(213, 411);
            this.btnSSTART.Name = "btnSSTART";
            this.btnSSTART.Size = new System.Drawing.Size(90, 29);
            this.btnSSTART.TabIndex = 5;
            this.btnSSTART.Text = "Stream Start";
            this.btnSSTART.UseSelectable = true;
            this.btnSSTART.Click += new System.EventHandler(this.btnSSTART_Click);
            // 
            // txtIPLINK
            // 
            // 
            // 
            // 
            this.txtIPLINK.CustomButton.Image = null;
            this.txtIPLINK.CustomButton.Location = new System.Drawing.Point(313, 1);
            this.txtIPLINK.CustomButton.Name = "";
            this.txtIPLINK.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtIPLINK.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtIPLINK.CustomButton.TabIndex = 1;
            this.txtIPLINK.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtIPLINK.CustomButton.UseSelectable = true;
            this.txtIPLINK.CustomButton.Visible = false;
            this.txtIPLINK.Lines = new string[] {
        "http://192.168.1.2:4747/mjpegfeed?640x480"};
            this.txtIPLINK.Location = new System.Drawing.Point(79, 369);
            this.txtIPLINK.MaxLength = 32767;
            this.txtIPLINK.Name = "txtIPLINK";
            this.txtIPLINK.PasswordChar = '\0';
            this.txtIPLINK.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtIPLINK.SelectedText = "";
            this.txtIPLINK.SelectionLength = 0;
            this.txtIPLINK.SelectionStart = 0;
            this.txtIPLINK.ShortcutsEnabled = true;
            this.txtIPLINK.Size = new System.Drawing.Size(335, 23);
            this.txtIPLINK.TabIndex = 3;
            this.txtIPLINK.Text = "http://192.168.1.2:4747/mjpegfeed?640x480";
            this.txtIPLINK.UseSelectable = true;
            this.txtIPLINK.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtIPLINK.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtIPLINK.Click += new System.EventHandler(this.txtIPLINK_Click);
            // 
            // videoBOX
            // 
            this.videoBOX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.videoBOX.Location = new System.Drawing.Point(3, 4);
            this.videoBOX.Name = "videoBOX";
            this.videoBOX.Size = new System.Drawing.Size(436, 347);
            this.videoBOX.TabIndex = 2;
            this.videoBOX.TabStop = false;
            // 
            // botCONTROL
            // 
            this.botCONTROL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.botCONTROL.Controls.Add(this.botCAR);
            this.botCONTROL.Controls.Add(this.botARM);
            this.botCONTROL.Controls.Add(this.cmbCOMP);
            this.botCONTROL.Controls.Add(this.btnDISCONNECT);
            this.botCONTROL.Controls.Add(this.btnCONNECT);
            this.botCONTROL.HorizontalScrollbarBarColor = true;
            this.botCONTROL.HorizontalScrollbarHighlightOnWheel = false;
            this.botCONTROL.HorizontalScrollbarSize = 10;
            this.botCONTROL.Location = new System.Drawing.Point(455, 63);
            this.botCONTROL.Name = "botCONTROL";
            this.botCONTROL.Size = new System.Drawing.Size(358, 451);
            this.botCONTROL.TabIndex = 1;
            this.botCONTROL.VerticalScrollbarBarColor = true;
            this.botCONTROL.VerticalScrollbarHighlightOnWheel = false;
            this.botCONTROL.VerticalScrollbarSize = 10;
            // 
            // botCAR
            // 
            this.botCAR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.botCAR.Controls.Add(this.btnLEFT);
            this.botCAR.Controls.Add(this.btnFORWARD);
            this.botCAR.Controls.Add(this.btnBACKWARD);
            this.botCAR.Controls.Add(this.btnRIGHT);
            this.botCAR.HorizontalScrollbarBarColor = true;
            this.botCAR.HorizontalScrollbarHighlightOnWheel = false;
            this.botCAR.HorizontalScrollbarSize = 10;
            this.botCAR.Location = new System.Drawing.Point(3, 3);
            this.botCAR.Name = "botCAR";
            this.botCAR.Size = new System.Drawing.Size(350, 259);
            this.botCAR.TabIndex = 5;
            this.botCAR.VerticalScrollbarBarColor = true;
            this.botCAR.VerticalScrollbarHighlightOnWheel = false;
            this.botCAR.VerticalScrollbarSize = 10;
            // 
            // btnLEFT
            // 
            this.btnLEFT.ActiveControl = null;
            this.btnLEFT.Location = new System.Drawing.Point(43, 94);
            this.btnLEFT.Name = "btnLEFT";
            this.btnLEFT.Size = new System.Drawing.Size(80, 74);
            this.btnLEFT.TabIndex = 7;
            this.btnLEFT.Text = "Left";
            this.btnLEFT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnLEFT.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.btnLEFT.UseSelectable = true;
            this.btnLEFT.Click += new System.EventHandler(this.btnLEFT_Click);
            // 
            // btnFORWARD
            // 
            this.btnFORWARD.ActiveControl = null;
            this.btnFORWARD.Location = new System.Drawing.Point(129, 52);
            this.btnFORWARD.Name = "btnFORWARD";
            this.btnFORWARD.Size = new System.Drawing.Size(93, 74);
            this.btnFORWARD.TabIndex = 8;
            this.btnFORWARD.Text = "Forward";
            this.btnFORWARD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnFORWARD.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.btnFORWARD.UseSelectable = true;
            this.btnFORWARD.Click += new System.EventHandler(this.btnFORWARD_Click);
            // 
            // btnBACKWARD
            // 
            this.btnBACKWARD.ActiveControl = null;
            this.btnBACKWARD.Location = new System.Drawing.Point(129, 132);
            this.btnBACKWARD.Name = "btnBACKWARD";
            this.btnBACKWARD.Size = new System.Drawing.Size(93, 74);
            this.btnBACKWARD.TabIndex = 9;
            this.btnBACKWARD.Text = "Backword";
            this.btnBACKWARD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnBACKWARD.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.btnBACKWARD.UseSelectable = true;
            this.btnBACKWARD.Click += new System.EventHandler(this.btnBACKWARD_Click);
            // 
            // btnRIGHT
            // 
            this.btnRIGHT.ActiveControl = null;
            this.btnRIGHT.Location = new System.Drawing.Point(228, 94);
            this.btnRIGHT.Name = "btnRIGHT";
            this.btnRIGHT.Size = new System.Drawing.Size(80, 74);
            this.btnRIGHT.TabIndex = 10;
            this.btnRIGHT.Text = "Right";
            this.btnRIGHT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnRIGHT.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.btnRIGHT.UseSelectable = true;
            this.btnRIGHT.Click += new System.EventHandler(this.btnRIGHT_Click);
            // 
            // botARM
            // 
            this.botARM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.botARM.Controls.Add(this.btnACTIVATEARM);
            this.botARM.HorizontalScrollbarBarColor = true;
            this.botARM.HorizontalScrollbarHighlightOnWheel = false;
            this.botARM.HorizontalScrollbarSize = 10;
            this.botARM.Location = new System.Drawing.Point(3, 268);
            this.botARM.Name = "botARM";
            this.botARM.Size = new System.Drawing.Size(200, 100);
            this.botARM.TabIndex = 2;
            this.botARM.VerticalScrollbarBarColor = true;
            this.botARM.VerticalScrollbarHighlightOnWheel = false;
            this.botARM.VerticalScrollbarSize = 10;
            // 
            // btnACTIVATEARM
            // 
            this.btnACTIVATEARM.ActiveControl = null;
            this.btnACTIVATEARM.Location = new System.Drawing.Point(43, 22);
            this.btnACTIVATEARM.Name = "btnACTIVATEARM";
            this.btnACTIVATEARM.Size = new System.Drawing.Size(110, 60);
            this.btnACTIVATEARM.TabIndex = 3;
            this.btnACTIVATEARM.Text = "Activate Arm";
            this.btnACTIVATEARM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnACTIVATEARM.TileTextFontWeight = MetroFramework.MetroTileTextWeight.Bold;
            this.btnACTIVATEARM.UseSelectable = true;
            this.btnACTIVATEARM.Click += new System.EventHandler(this.btnACTIVATEARM_Click);
            // 
            // cmbCOMP
            // 
            this.cmbCOMP.FormattingEnabled = true;
            this.cmbCOMP.ItemHeight = 23;
            this.cmbCOMP.Location = new System.Drawing.Point(16, 410);
            this.cmbCOMP.Name = "cmbCOMP";
            this.cmbCOMP.Size = new System.Drawing.Size(111, 29);
            this.cmbCOMP.TabIndex = 4;
            this.cmbCOMP.UseSelectable = true;
            // 
            // btnDISCONNECT
            // 
            this.btnDISCONNECT.Location = new System.Drawing.Point(258, 410);
            this.btnDISCONNECT.Name = "btnDISCONNECT";
            this.btnDISCONNECT.Size = new System.Drawing.Size(85, 29);
            this.btnDISCONNECT.TabIndex = 2;
            this.btnDISCONNECT.Text = "DisConnect";
            this.btnDISCONNECT.UseSelectable = true;
            this.btnDISCONNECT.Click += new System.EventHandler(this.btnDISCONNECT_Click);
            // 
            // btnCONNECT
            // 
            this.btnCONNECT.Location = new System.Drawing.Point(156, 410);
            this.btnCONNECT.Name = "btnCONNECT";
            this.btnCONNECT.Size = new System.Drawing.Size(96, 29);
            this.btnCONNECT.TabIndex = 2;
            this.btnCONNECT.Text = "Connect";
            this.btnCONNECT.UseSelectable = true;
            this.btnCONNECT.Click += new System.EventHandler(this.btnCONNECT_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(822, 526);
            this.Controls.Add(this.botCONTROL);
            this.Controls.Add(this.videoSTREAM);
            this.Name = "Form1";
            this.Text = "BOT";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.videoSTREAM.ResumeLayout(false);
            this.videoSTREAM.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.videoBOX)).EndInit();
            this.botCONTROL.ResumeLayout(false);
            this.botCAR.ResumeLayout(false);
            this.botARM.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel videoSTREAM;
        private MetroFramework.Controls.MetroPanel botCONTROL;
        private MetroFramework.Controls.MetroComboBox cmbCOMP;
        private MetroFramework.Controls.MetroButton btnCONNECT;
        private System.IO.Ports.SerialPort serialPort1;
        private MetroFramework.Controls.MetroLabel lblLINK;
        private MetroFramework.Controls.MetroButton btnSSTOP;
        private MetroFramework.Controls.MetroButton btnSSTART;
        private MetroFramework.Controls.MetroTextBox txtIPLINK;
        private System.Windows.Forms.PictureBox videoBOX;
        private MetroFramework.Controls.MetroPanel botCAR;
        private MetroFramework.Controls.MetroTile btnLEFT;
        private MetroFramework.Controls.MetroTile btnFORWARD;
        private MetroFramework.Controls.MetroTile btnBACKWARD;
        private MetroFramework.Controls.MetroTile btnRIGHT;
        private MetroFramework.Controls.MetroPanel botARM;
        private MetroFramework.Controls.MetroTile btnACTIVATEARM;
        private MetroFramework.Controls.MetroButton btnDISCONNECT;
    }
}

