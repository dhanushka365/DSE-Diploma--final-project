﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using AForge.Video;
using AForge.Video.DirectShow;

namespace controlapp
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        MJPEGStream stream;
        public Form1()
        {
            
            InitializeComponent();
                //show list of valid com ports
                foreach (string port in System.IO.Ports.SerialPort.GetPortNames())
                {
                    cmbCOMP.Items.Add(port);
                }
        }

        private void stream_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {   
            Bitmap bmp = (Bitmap)eventArgs.Frame.Clone();
            videoBOX.Image = bmp;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtIPLINK_Click(object sender, EventArgs e)
        {

        }

        private void btnSSTART_Click(object sender, EventArgs e)
        {
            try {
                //Start the video stream
                string iplink = txtIPLINK.Text;
                stream = new MJPEGStream(iplink);
                stream.NewFrame += stream_NewFrame;
                stream.Start();
            }catch(Exception ex)
            { MessageBox.Show(ex.Message);}
        }

        private void btnSSTOP_Click(object sender, EventArgs e)
        {
            try {//Stop the video stream
                stream.Stop();
            }catch(Exception ex)
            { MessageBox.Show(ex.Message); }
        }

        private void btnCONNECT_Click(object sender, EventArgs e)
        {
            try {//Select & connect the bluetooth device
                serialPort1.PortName = this.cmbCOMP.GetItemText(this.cmbCOMP.SelectedItem);
                serialPort1.BaudRate = 9600;
                serialPort1.Open();
                if (!serialPort1.IsOpen) return;
                btnCONNECT.Enabled = false;

                MessageBox.Show("Connected", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }catch(Exception ex)
            { MessageBox.Show(ex.Message); }
        }

        private void btnDISCONNECT_Click(object sender, EventArgs e)
        {
            try
            {//Disconnect the bluetooth
                if (serialPort1.IsOpen)
                serialPort1.Close();
            btnCONNECT.Enabled = true;
            MessageBox.Show("Disconnected", "Notification", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

        }
        //Send Commands
        private void btnFORWARD_Click(object sender, EventArgs e)
        {
            try {
                serialPort1.Write("C");
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

        }

        private void btnBACKWARD_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.Write("B");
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }

        private void btnLEFT_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.Write("D");
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }

        private void btnRIGHT_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.Write("E");
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }

        private void btnACTIVATEARM_Click(object sender, EventArgs e)
        {
            try { //select the text file
                string path = Environment.CurrentDirectory + "/" + "abc.txt";
                if (!File.Exists(path))
                {
                    MessageBox.Show("File not found");
                }
                else
                {
                    using (StreamReader sr = new StreamReader(path))
                    {//Read data from text file
                        string text = sr.ReadLine();
                        try
                        {
                            serialPort1.Write(text);
                        }
                        catch (Exception ex)
                        { MessageBox.Show(ex.Message); }
                    }


                }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }

        }
    }
}
