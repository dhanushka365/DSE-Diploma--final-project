url = 'http://10.103.226.176:8080//shot.jpg';
ri  = imread(url);
fh = image(ri);

while(1)
    ri = imread(url);
    mask = ((ri(:, :, 1) >= 40)&(ri(:, :, 1) <= 185))&((ri(:, :, 2) >= 0)&(ri(:, :, 2) <= 124)&((ri(:, :, 3)>=0)&(ri(:, :, 3)<=125)));
    maskedRgbImage = bsxfun(@times, ri, cast(mask, 'like', ri));
    set(fh,'CData',maskedRgbImage);
    drawnow;
end


