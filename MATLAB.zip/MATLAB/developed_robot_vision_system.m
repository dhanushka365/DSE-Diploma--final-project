url = 'http://10.103.226.176:8080//shot.jpg';
ri  = imread(url);
fh = image(ri);
count = 0;
while(1)
    ri = imread(url);
    mask = ((ri(:, :, 1) >= 40)&(ri(:, :, 1) <= 185))&((ri(:, :, 2) >= 0)&(ri(:, :, 2) <= 124)&((ri(:, :, 3)>=0)&(ri(:, :, 3)<=125)));
    maskedRgbImage = bsxfun(@times, ri, cast(mask, 'like', ri));
    cropped = imcrop(maskedRgbImage,[550 310 100 100]);
    
    for jj = 1:100
        for ii = 1:100
          x = cropped(ii, jj,:); 
          if (x(:,:,1)&x(:,:,2)&x(:,:,3)) == 0
           count = count + 1;    
          end
          %disp(count);
          if(count>9000)
              
              fprintf('Object Identified');
              count = 0;
              clc;
%               word = 'A';
%               fileID = fopen('C:\Users\Dhanushka Uduwela\Desktop\fayaz','w');
%               typed = fprintf(fileID,'%c\n',word);
%               
              %jj = 200;
          
          else
              
%               word = '';
%               fileID = fopen('C:\Users\Dhanushka Uduwela\Desktop\fayaz','w');
%               typed = fprintf(fileID,'%c\n',word);
              
          end
        end
    end      
    set(fh,'CData',cropped);
    drawnow;
    
end


