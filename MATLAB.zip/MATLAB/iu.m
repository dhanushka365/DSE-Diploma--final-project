url = 'http://10.103.226.176:8080//shot.jpg';
ri  = imread(url);
fh = image(ri);
z = 1;
i = 0;
s = zeros(720,1200,'uint32');
t = zeros(720,1200,'uint32');
u = zeros(720,1200,'uint32');
while(z<=1)
    ri = imread(url);
    z = z+1;
    set(fh,'CData',ri);
    drawnow;
end

    for jj = 1:1200
        for ii = 1:720
          x = ri(ii, jj,:); 
      
          A = x(:,:,1);
          B = x(:,:,2);
          C = x(:,:,3);
           
          s(ii,jj) = A;
          t(ii,jj) = B;
          u(ii,jj) = C;
        
          %A
          %B
          %C
        end
    end

          
           a = unique(s);
           b = unique(t);
           c = unique(u);
%           
 out1 = [a,histc(s(:),a)];
 out2 = [b,histc(t(:),b)];
 out3 = [c,histc(u(:),c)];
 %out
 fprintf('out1');
 out1
 fprintf('out2');
 out2
 fprintf('out3');
 out3
