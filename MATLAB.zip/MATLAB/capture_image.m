%arduino initializing
a = arduino('COM23','Uno');

%image capturing
url = 'http://10.103.226.176:8080//shot.jpg';
ri  = imread(url);
fh = image(ri);
while(1)
    ri = imread(url);
    set(fh,'CData',ri);
    drawnow;
    i = readDigitalPin(a,'D2');
    if(i == 1)
        break;
    end  
end

%image seperation 
figure,imshow(ri);
hold on;

%image pre processing
gray = rgb2gray(ri);
gray = medfilt2(gray);
[XS YS] = size(gray);
XS;
YS;
imshow(gray);
%hold on;

%edge detecting
BWtemp = edge(gray,'Canny');
%imshow(BWtemp);

%image filling
se = strel('line',2,0);
BW2 = imdilate(BWtemp,se);
BW2temp = imfill(BW2,'holes');
cctemp = bwconncomp(BW2temp);

%label components
labeltemp = labelmatrix(cctemp);
imshow(BW2temp);
hold on;

%pixel identification & verification
statstemp = regionprops(cctemp, 'Area','BoundingBox','Image');
idstemp = find([statstemp.Area] > (40000) & [statstemp.Area] < (400000));
BW3temp = ismember(labeltemp,idstemp);
cctemp = bwconncomp(BW3temp);
x = cctemp.PixelIdxList; 
labeltemp = labelmatrix(cctemp);
statstemp = regionprops(cctemp, 'Area','BoundingBox','Image');
L = length(idstemp);
L

%image cropping
for k = 1:length(x)
BB = statstemp.BoundingBox;
rectangle('Position',[BB(1),BB(2), BB(3), BB(4)], 'EdgeColor','r');  
z = [BB(1),BB(2), BB(3), BB(4)];
P = BB(3)/BB(4);

    if(P>2.25 && P<6)
    Z = imcrop(gray,z);
    end 
    
end
imshow(BB);
hold on;
rectangle('Position',[BB(1),BB(2), BB(3), BB(4)], 'EdgeColor','r');  
figure,imshow(Z);

%binarizing image for number detection
Zbinary = im2bw(Z,0.53);
Zconbinary = ~Zbinary;
figure,imshow(Zconbinary);


%%Extracting numbers from image
%Reading numbers
Zcctemp = bwconncomp(Zconbinary);
Zlabeltemp = labelmatrix(Zcctemp);
Zstatstemp = regionprops(Zcctemp, 'Area','BoundingBox','Image');
Zidstemp = find([Zstatstemp.Area] > (100) & [Zstatstemp.Area] < (5000));
ZBWtemp = ismember(Zlabeltemp,Zidstemp);
Zcctemp2 = bwconncomp(ZBWtemp);
F  = length(Zidstemp);
F


%cropping images with numbers
for k = 1:F+1
    BBZ = Zstatstemp(k).BoundingBox;
    zz = [BBZ(1),BBZ(2), BBZ(3), BBZ(4)];
    PZ = BBZ(3)/BBZ(4);
        if(PZ<0.8)
        Z = imcrop(Zconbinary,zz);
        Z = resizem(Z,[60,30]);
        ex_images{i} = Z;
        i = i+1;
        n = i;
        end 
    figure,imshow(Z);
end


%Reading image files from directory
imagefiles = dir('Images');      
nfiles = length(imagefiles);  
oi = 1;
CH = 1;
for ii=1:nfiles
   if(ii>2)
       currentfilename = imagefiles(ii).name;
       currentimage = imread(currentfilename);
       images{ii} = currentimage;
       gray = rgb2gray(images{ii});
       gray = medfilt2(gray);
       gray = imadjust(gray,[0.2 0.8],[]);
       Zbinary = im2bw(gray,0.5);
       Zconbinary = ~Zbinary;
       u = resizem(Zconbinary,[60,30]);
       new_images{oi} = u;
       
       switch oi
       
           case  1
           ch{CH} = '0';
           CH = CH + 1;
           case  2
           ch{CH} = '1'; 
           CH = CH + 1;
           case  3
           ch{CH} = '2';  
           CH = CH + 1;
           case  4
           ch{CH} = '3';
           CH = CH + 1;
           case  5
           ch{CH} = '4'; 
           CH = CH + 1;
           case  6
           ch{CH} = '5'; 
           CH = CH + 1;
           case  7
           ch{CH} = '6'; 
           CH = CH + 1;
           case  8
           ch{CH} = '7';
           CH = CH + 1;
           case  9
           ch{CH} = '8';
           CH = CH + 1;
           case  10
           ch{CH} = '9';
           CH = CH + 1;
           
       end
       oi = oi + 1;
   end
end


%Correlating templates
max=0;P=1;num =1;
for i = 1:5
    for oi=1:10
            s = corr2(new_images{oi},ex_images{i});
            if (s >= max)
                max = s;
                fin_images{P} = new_images{oi};
                CH = oi;
                read_char{num} = ch{CH};
            end
    end 
    figure,imshow(fin_images{i});
    num = num + 1;
    Q = P;
    P = P + 1;
    max = 0;
end

CUSTOMER_NUMBER = read_char;
CUSTOMER_NUMBER 










  