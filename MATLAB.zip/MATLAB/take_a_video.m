%image capturing
url = 'http://10.103.226.176:8080//shot.jpg'; %put the IP address on IPweb app
ri  = imread(url);
fh = image(ri);
while(1)
    ri = imread(url);
    set(fh,'CData',ri);
    drawnow;
end
