clear
webcamlist
camera = webcam;
webcam.Resolution = '320x240';
mnet = alexnet;
while(1)
    picture = camera.snapshot;
    picture = imresize(picture,[227,227]);
    label = classify(mnet,picture);
    image(picture);
    title(char(label));
    drawnow;
end