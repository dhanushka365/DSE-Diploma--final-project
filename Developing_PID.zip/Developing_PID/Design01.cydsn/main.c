#include "project.h"
#include "math.h"
#include "stdio.h"

float rev;
char strMsg[50];
    
float X0 = 10;              //Assign values for coordinates
float Y0 = 17;
float Z0 = 9;
   
float a1 = 10;             //Lengths of links
float a2 = 10;
float a3 = 7.5;
    
float ak = 8;             //Length and angle of preset 
float Tk = 0;

int T0,T1,T2;

float deg2rad(float deg){
    
    float rad = (deg/180)*3.14;
    
    return rad;
}

float rad2deg(float rad){
    
    float deg = (rad/3.14)*180;
    
    return deg;
}

void calculate(){
    
    float r1 = (pow((pow(X0,2)+pow(Y0,2)),(1./2))-ak*cos(Tk));  //Calculate triangle distances
    float r2 = a1+ak*sin(Tk)-Z0;
    float r3 = pow((pow(r1,2)+pow(r2,2)),(1./2));
    
    float e1 =(pow(a3,2)-pow(a2,2)-pow(r3,2))/(-2*a2*r3);
    float e2 =(pow(r3,2)-pow(a2,2)-pow(a3,2))/(-2*a2*a3);
    
    float G1 = acos(e1);            //Calculate triangle angles
    float G2 = atan(r2/r1);
    float G3 = acos(e2);
                                                                           
    T0 = rad2deg(atan(Y0/X0));    //Calculate required angles to move
    T1 = rad2deg(G2)-rad2deg(G1); 
    T2 = 180 - rad2deg(G3);
    
    sprintf(strMsg,"%d",T0);
    UART_1_PutString(strMsg);
    UART_1_PutString("++");
    
    sprintf(strMsg,"%d",T1);
    UART_1_PutString(strMsg);
    UART_1_PutString("++");
    
    sprintf(strMsg,"%d",T2);
    UART_1_PutString(strMsg);
    UART_1_PutString("++");
        
}


int calAngle(float ang){
    // EQUTATION: y = ((ymax - ymin)/(xmax - xmin))*(x-xmin)+ymin;
   
    int com = ((7000-2800)/(180-0))*(ang-0)+2800; 
    return com;
    
}

void armcontrol(){
    
    PWM_2_WriteCompare1(calAngle(T0));
    CyDelay(1000); 
    PWM_1_WriteCompare1(calAngle(T1));
    CyDelay(1000);
    PWM_1_WriteCompare2(calAngle(T2)); 
    CyDelay(3000); 
    
    
    PWM_1_WriteCompare1(calAngle(0));
    CyDelay(1000);
    PWM_1_WriteCompare2(calAngle(0)); 
    CyDelay(1000); 
    PWM_2_WriteCompare1(calAngle(100));
    CyDelay(1000);
   
}

void distance(){
    
    while(Echo_Read() == 0){
         
        Trig_Write(1);
        CyDelay(10u);
        Trig_Write(0);
        CyDelay(1);
   
     }
     while(Echo_Read() == 1){}
        
        int count_pulse = 65535 - Timer_1_ReadCounter();
        int distance = count_pulse/58.0;
        Z0 = 18.9 - distance;
        sprintf(strMsg,"%d",distance);
        UART_1_PutString(strMsg);
        UART_1_PutString("++"); 
  
}


void stop(){
    
    IN_A1_Write(0);
    IN_A2_Write(0);
    IN_B1_Write(0);
    IN_B2_Write(0);
    
}

int main(void)
{
    
    Timer_1_Start();
    UART_1_Start();
    PWM_1_Start();
    PWM_2_Start();
    
    uint8 recieve;
    
    Tk = deg2rad(20);
    
    for(;;)
    {
         recieve = UART_1_GetChar();
      
         if(recieve == 'A'){
            
             stop();
             distance();
             calculate();
             armcontrol();
            
             recieve = 0;
             
         }else if(recieve == 'B'){   //Forward 
              
             IN_A1_Write(1);
             IN_A2_Write(0);
             IN_B1_Write(1);
             IN_B2_Write(0);
             
             CyDelay(250);
             //stop();
             
             recieve = 0;
             
            
         }else if(recieve == 'C'){   // Backward
              
             IN_A1_Write(0);
             IN_A2_Write(1);
             IN_B1_Write(0);
             IN_B2_Write(1);
            
             CyDelay(250);
             //stop();
            
             recieve = 0;
            
            
         }else if(recieve == 'D'){   //Left
              
             IN_A1_Write(0);
             IN_A2_Write(1);
             IN_B1_Write(1);
             IN_B2_Write(0);
            
             CyDelay(250);
             //stop();
             
             recieve = 0;
            
         }else if(recieve == 'E'){   //Right
              
             IN_A1_Write(1);
             IN_A2_Write(0);
             IN_B1_Write(0);
             IN_B2_Write(1);
            
             CyDelay(250);
             //stop();
             
             recieve = 0;
            
         }else if(recieve == 'Z'){
            
             stop();
             recieve = 0;
            
         } 
         
    }  
}


// DESIGN - MATH CODE.........................................................//
/*
#include "project.h"
#include "math.h"
#include "stdio.h"

    float rev;
    char strMsg[50];
    
    float X0 = 4;              //Assign values for coordinates
    float Y0 = 22;
    float Z0 = 3;
    
    float a1 = 7;             //Lengths of beams
    float a2 = 15;
    float a3 = 20;
    
    float ak = 5;             //Length and angle of preset 
    float Tk = 0;
       
float deg2rad(float deg){
    
    float rad = (deg/180)*3.14;
    
    return rad;
}

float rad2deg(float rad){
    
    float deg = (rad/3.14)*180;
    
    return deg;
}

void calculate(){
    
    float r1 = (pow((pow(X0,2)+pow(Y0,2)),(1./2))-ak*cos(Tk));  //Calculate triangle distances
    float r2 = a1+ak*sin(Tk)-Z0;
    float r3 = pow((pow(r1,2)+pow(r2,2)),(1./2));
    
    float e1 =(pow(a3,2)-pow(a2,2)-pow(r3,2))/(-2*a2*r3);
    float e2 =(pow(r3,2)-pow(a2,2)-pow(a3,2))/(-2*a2*a3);
    
    float G1 = acos(e1);  //Calculate triangle angles
    float G2 = atan(r2/r1);
    float G3 = acos(e2);
                                                                           
    int T0 = rad2deg(atan(Y0/X0));    //Calculate required angles to move
    int T1 = rad2deg(G2)-rad2deg(G1); 
    int T2 = 180 - rad2deg(G3);
    
    sprintf(strMsg,"%d",T0);
    UART_1_PutString(strMsg);
    UART_1_PutString("++");
    
    sprintf(strMsg,"%d",T1);
    UART_1_PutString(strMsg);
    UART_1_PutString("++");
    
    sprintf(strMsg,"%d",T2);
    UART_1_PutString(strMsg);
    UART_1_PutString("++");
    
    
    
}

int main(void)
{
    UART_1_Start();
    
    Tk = deg2rad(45);

   
    for(;;)
    {
     
        calculate();   
        
          
    }
    
}

*/

