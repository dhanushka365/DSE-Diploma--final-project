#include "project.h"

int main(void)
{
    UART_1_Start();
    char recieve;
    for(;;)
    {
        recieve = UART_1_GetChar();
        //PWM_1_Start();
        
        if(recieve == 'A'){
            
            LED_Write(1);
            CyDelay(1000);
            LED_Write(0);
            CyDelay(1000);
            
            IN_A1_Write(1);
            IN_A2_Write(0);
            IN_B1_Write(1);
            IN_B2_Write(0);
            
         /*PWM_1_WriteCompare1(6000);
         CyDelay(1000);
         PWM_1_WriteCompare1(2000);
         CyDelay(1000);*/
          
         //recieve = '0';
            
        } 
        
    }
}


